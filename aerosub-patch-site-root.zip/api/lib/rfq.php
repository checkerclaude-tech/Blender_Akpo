<?php
declare(strict_types=1);
// RFQ tracker (Finance). Reads the operations@ (or any chosen) mailbox:
//   * a request for quotation -> a tracker entry with its code + an action task "Create proforma / quotation" for Finance
//   * the quotation made in Finance for that RFQ (same RFQ ref, or made from the task) -> its number is stored and the RFQ is marked quoted once it is sent
//   * a purchase order that mentions the RFQ code -> the RFQ is marked PO received, with the PO number, and a task to prepare delivery
//   * a delivery note -> the delivery date goes into the tracker; the note is signed by an Aerosub user and printed for the client to sign
//   * once printed, the user confirms the payment -> the sale is recorded
// Functions are used by cron.php too; the routes run only when finance.php includes this file for finance/rfqs and finance/delivery.
//   GET  finance/rfqs[?status=&q=]   POST finance/rfqs (add by hand)   GET|PATCH finance/rfqs/{id}   POST finance/rfqs/scan   GET|PUT finance/rfqs/settings
//   POST finance/rfqs/{id}/po {po_number}   POST finance/rfqs/{id}/delivery {delivery_date,delivery_address,items?}   POST finance/rfqs/{id}/payment {amount,date,reference}
//   GET|PATCH finance/delivery/{id}   POST finance/delivery/{id}/sign   POST finance/delivery/{id}/printed
require_once __DIR__ . '/mail.php'; require_once __DIR__ . '/inboxauto.php'; require_once __DIR__ . '/rfqread.php'; require_once __DIR__ . '/vendorcrm.php';

/** Only senders on the allowed list are ever read. Entries: an address (buyer@client.com), a whole domain (@client.com or client.com). An empty list allows nobody. */
function rfq_allow_list(?string $raw): array { $o = []; foreach (preg_split('/[\s,;]+/', strtolower((string)$raw)) as $e) { $e = trim($e, " <>\t\"'"); if ($e === '') continue; $e = preg_replace('/^\*@/', '@', $e); if (preg_match('/^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/', $e) || preg_match('/^@?[a-z0-9\-]+(\.[a-z0-9\-]+)*\.[a-z]{2,}$/', $e)) $o[$e] = 1; } return array_slice(array_keys($o), 0, 300); }
function rfq_allowed(string $email, ?string $raw): bool { $email = strtolower(trim($email)); $dom = substr(strrchr($email, '@') ?: '', 1); if ($email === '' || $dom === '') return false; foreach (rfq_allow_list($raw) as $e) { if ($e === $email) return true; $d = ltrim($e, '@'); if (!str_contains($e, '@') || $e[0] === '@') { if ($dom === $d || str_ends_with($dom, '.' . $d)) return true; } } return false; }
/** Customers picked in the Pipeline (a company or a contact marked "can send us RFQs"), as allow-list lines. Vendors and partners are never added this way. */
function rfq_designated(): array {
    vc_ensure(); $o = [];
    try {
        foreach (all("SELECT LOWER(email) e FROM contacts WHERE rfq_ok=1 AND vendor_id IS NULL AND email IS NOT NULL AND email<>''") as $x) $o[$x['e']] = 1;
        foreach (all("SELECT website FROM companies WHERE rfq_ok=1 AND website IS NOT NULL AND website<>''") as $x) { $d = strtolower(preg_replace('~^https?://(www\.)?~i', '', trim((string)$x['website']))); $d = explode('/', $d)[0]; if ($d !== '' && !in_array($d, VC_FREE, true)) $o['@' . $d] = 1; }
        foreach (all("SELECT LOWER(ct.email) e FROM contacts ct JOIN companies c ON c.id=ct.company_id WHERE c.rfq_ok=1 AND ct.vendor_id IS NULL AND ct.email IS NOT NULL AND ct.email<>''") as $x) $o[$x['e']] = 1;   // a company with no website: its people
    } catch (Throwable $e) { error_log('RFQ designated: ' . $e->getMessage()); }
    return array_keys($o);
}
/** Who may be read: the allowed-senders list plus the designated customers. Vendors and partners are left out unless typed into the list by hand. Our own people never count. */
function rfq_effective_allow(?string $raw): string {
    $typed = rfq_allow_list($raw); $des = array_diff(rfq_designated(), $typed); $keep = [];
    foreach ($des as $e) { $em = ltrim($e, '@'); if (str_contains($e, '@') && $e[0] !== '@' ? vc_vendor_for($e) : false) continue; $keep[] = $e; }   // a designated address that is really a vendor contact is dropped
    return implode("\n", array_merge($typed, $keep));
}
/** Is this address one of ours (our domain, the scanned mailbox, or any staff address)? Such mail is never an RFQ. */
function rfq_is_ours(string $email, string $mailbox): bool {
    $email = strtolower(trim($email)); $dom = vc_domain($email); if ($email === '' || $dom === '') return false; $mb = strtolower($mailbox); if ($email === $mb || ($mb !== '' && $dom === vc_domain($mb))) return true;
    static $ours = null; if ($ours === null) { $ours = ['mail' => [], 'dom' => []]; try { foreach (all("SELECT LOWER(email) e FROM users WHERE email IS NOT NULL AND email<>''") as $x) $ours['mail'][$x['e']] = 1; foreach (all('SELECT LOWER(email) e FROM mail_accounts') as $x) { $ours['mail'][$x['e']] = 1; $ours['dom'][vc_domain($x['e'])] = 1; }
        $fs = one('SELECT email FROM fin_settings WHERE id=1'); if (!empty($fs['email'])) $ours['dom'][vc_domain((string)$fs['email'])] = 1; foreach (explode(',', (string)(cfg('own_domains') ?: '')) as $d) if (trim($d) !== '') $ours['dom'][strtolower(trim($d))] = 1; } catch (Throwable $e) { error_log('RFQ own addresses: ' . $e->getMessage()); }
        foreach (array_keys($ours['mail']) as $e) { $dd = vc_domain($e); if (in_array($dd, VC_FREE, true)) continue; $ours['dom'][$dd] = 1; }   // staff on a company domain make that domain ours
        foreach (array_keys($ours['dom']) as $dd) if (in_array($dd, VC_FREE, true)) unset($ours['dom'][$dd]); }
    return isset($ours['mail'][$email]) || isset($ours['dom'][$dom]);
}
function rfq_dir(): string { $dir = (string)(cfg('storage_dir') ?: dirname(__DIR__) . '/storage') . '/rfq'; if (!is_dir($dir)) @mkdir($dir, 0775, true); $root = dirname($dir); if (!is_file($root . '/.htaccess')) { @file_put_contents($root . '/.htaccess', "Require all denied\nDeny from all\n"); @file_put_contents($root . '/index.html', ''); } return $dir; }
function rfq_save_files(int $id, string $kind, array $files): void { foreach (array_slice($files, 0, 6) as $f) { $rel = bin2hex(random_bytes(16)); if (@file_put_contents(rfq_dir() . '/' . $rel, $f['data']) === false) continue; q('INSERT INTO rfq_files (rfq_id,kind,name,mime,size,path) VALUES (?,?,?,?,?,?)', [$id, $kind, $f['name'], mb_substr((string)$f['mime'], 0, 100), strlen($f['data']), $rel]); } }
function rfq_store_items(int $id, array $ex): void { if (!$ex['items']) return; q('UPDATE rfqs SET items_json=?, items_source=? WHERE id=?', [json_encode($ex['items'], JSON_UNESCAPED_UNICODE), mb_substr($ex['source'], 0, 190), $id]); rfq_event($id, 'items', count($ex['items']) . ' item' . (count($ex['items']) === 1 ? '' : 's') . ' read from ' . $ex['source']); }
function rfq_items_line(array $items): string { $o = []; foreach (array_slice($items, 0, 12) as $i => $it) $o[] = ($i + 1) . '. ' . mb_substr((string)$it['description'], 0, 90) . ' - ' . rtrim(rtrim(number_format((float)$it['qty'], 2, '.', ''), '0'), '.') . ' ' . $it['unit']; return implode("\n", $o) . (count($items) > 12 ? "\n… and " . (count($items) - 12) . ' more' : ''); }
function rfq_ensure(): void {
    static $d = false; if ($d) return; $d = true;
    try { require_once __DIR__ . '/migrate.php'; if (!one("SHOW TABLES LIKE 'rfqs'") || !one("SHOW TABLES LIKE 'delivery_notes'") || !col_exists('rfqs', 'payment_status')) { require_once __DIR__ . '/migrate_fin3.php'; migrate_fin_ext(); } } catch (Throwable $e) { error_log('RFQ schema: ' . $e->getMessage()); }
    if (!one('SELECT id FROM rfq_settings WHERE id=1')) q('INSERT INTO rfq_settings (id) VALUES (1)');
}
function rfq_settings(): array { rfq_ensure(); return one('SELECT * FROM rfq_settings WHERE id=1') ?: []; }
function rfq_norm(string $s): string { return strtoupper(preg_replace('/[^A-Za-z0-9]+/', '', $s)); }
function rfq_event(int $id, string $kind, string $text, ?int $uid = null): void { q('INSERT INTO rfq_events (rfq_id,kind,text,user_id) VALUES (?,?,?,?)', [$id, $kind, mb_substr($text, 0, 400), $uid]); q('UPDATE rfqs SET updated_at=NOW() WHERE id=?', [$id]); }
const RFQ_WORDS = '/\b(rfq|request for (quotation|quote|proposal|price)|requests? for (quotation|quote)|invitation (to|for) (tender|bid|quote)|\bitt\b|please quote|kindly quote|quotation request|request a quotation|tender (no|number|ref)|call for (tender|bids?))\b/i';
const RFQ_PO_WORDS = '/\b(purchase order|\blpo\b|\bp\.?o\.?\b|work order|order (no|number|confirmation)|we (hereby )?(award|confirm the order))\b/i';
/** The reference the client gave the request, e.g. "RFQ-2026-0042" or "NLNG/ITT/123". Needs at least one digit. */
function rfq_find_code(string $subject, string $body): ?string {
    foreach ([$subject, mb_substr($body, 0, 3000)] as $t) {
        if (preg_match('/\b(?:RFQ|ITT|RFP|RFQN|TENDER)[\s#:.\-]*(?:No\.?|Number|Ref(?:erence)?\.?|ID)?[\s#:.\-]*([A-Z0-9][A-Z0-9\/_.\-]{2,38})/i', $t, $m) && preg_match('/\d/', $m[1])) { $c = rtrim($m[1], '.-/_'); $pre = strtoupper(preg_match('/^(RFQ|ITT|RFP)/i', $m[0], $pp) ? $pp[1] : ''); return (stripos($c, 'RFQ') === 0 || $pre === '' ? $c : ($pre . '-' . $c)); }
        if (preg_match('/\b([A-Z]{2,6}[\/\-][A-Z0-9]{2,8}[\/\-]\d{2,}[A-Z0-9\/\-]*)\b/', $t, $m) && preg_match('/\d/', $m[1])) return $m[1];
    }
    return null;
}
function rfq_find_po(string $subject, string $body): ?string {
    foreach ([$subject, mb_substr($body, 0, 4000)] as $t) if (preg_match('/\b(?:LPO|P\.?O\.?|Purchase Order|Order)[\s#:.\-]*(?:No\.?|Number|Ref\.?)?[\s#:.\-]*([A-Z0-9][A-Z0-9\/_.\-]{2,30})/i', $t, $m) && preg_match('/\d/', $m[1]) && !preg_match('/^(RFQ)/i', $m[1])) return rtrim($m[1], '.-/_');
    return null;
}
function rfq_find_date(string $text): ?string {
    if (!preg_match('/(closing|close|deadline|due|submit(?:ted)?|submission|return(?:ed)?|respond)[^.\n]{0,40}?(?:by|on|before|date|:)[^0-9A-Za-z]{0,6}(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?[A-Za-z]{3,9},?\s+\d{4})/i', mb_substr($text, 0, 4000), $m)) return null;
    $d = trim($m[2]); if (preg_match('~^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})$~', $d, $x)) { $y = (int)$x[3] < 100 ? 2000 + (int)$x[3] : (int)$x[3]; $d = sprintf('%04d-%02d-%02d', $y, (int)$x[2], (int)$x[1]); } else $d = preg_replace('/(\d)(st|nd|rd|th)/i', '$1', str_replace(' of ', ' ', $d));
    $t = strtotime($d); return $t && $t > strtotime('-1 year') && $t < strtotime('+3 years') ? date('Y-m-d', $t) : null;
}
function rfq_next_code(): string { $n = (int)(one("SELECT COUNT(*) n FROM rfqs WHERE code LIKE ?", ['RFQ-' . date('ym') . '-%'])['n'] ?? 0) + 1; do { $c = 'RFQ-' . date('ym') . '-' . str_pad((string)$n++, 3, '0', STR_PAD_LEFT); } while (one('SELECT id FROM rfqs WHERE code=?', [$c])); return $c; }
function rfq_assignee(array $st, array $actor): array {
    $dept = one("SELECT id,head_id FROM departments WHERE name='Finance' LIMIT 1"); $to = (int)($st['assign_user_id'] ?? 0);
    if (!$to && $dept && $dept['head_id']) $to = (int)$dept['head_id']; if (!$to) $to = (int)$actor['id']; return [$to, $dept ? (int)$dept['id'] : null];
}
function rfq_task(int $rfqId, string $title, string $desc, ?string $due, array $st, array $actor, bool $self = false): int {
    [$to, $dept] = rfq_assignee($st, $actor); if ($self) $to = (int)$actor['id'];   // reviewed and added by this person: it is theirs
    q("INSERT INTO tasks (title,description,status,priority,assignee_id,creator_id,department_id,due_date,task_type,source) VALUES (?,?,'todo','high',?,?,?,?,'rfq','rfq')", [mb_substr($title, 0, 200), mb_substr($desc, 0, 4000), $to, (int)$actor['id'], $dept, $due ?: date('Y-m-d', strtotime('+3 days'))]);
    $tid = (int)db()->lastInsertId(); if ($to !== (int)$actor['id']) notify($to, 'task_assigned', 'New task: ' . mb_substr($title, 0, 150), 'RFQ tracker', '#/tasks/' . $tid); return $tid;
}
/** The words of the task for an RFQ: what to do depends on how far it has got. */
function rfq_task_text(array $r): array {
    $items = json_decode((string)($r['items_json'] ?? ''), true) ?: [];
    if ($r['status'] === 'po_received') return ['Prepare delivery note and invoice: PO ' . $r['po_number'] . ' (RFQ ' . $r['code'] . ')', 'Purchase order ' . $r['po_number'] . ' received' . ($r['po_from'] ? ' from ' . $r['po_from'] : '') . ' for RFQ ' . $r['code'] . ($r['quote_number'] ? ' (quotation ' . $r['quote_number'] . ')' : '') . ".\nOpen the RFQ tracker in Finance to create the delivery note."];
    return ['Create proforma / quotation: ' . $r['client_name'] . ' (RFQ ' . $r['code'] . ')', 'Request for quotation from ' . ($r['client_email'] ?: $r['client_name']) . ".\nRFQ code: " . $r['code'] . ($r['due_date'] ? "\nClosing date: " . $r['due_date'] : '') . "\nSubject: " . $r['subject'] . ($items ? "\n\nItems requested:\n" . rfq_items_line($items) : "\n\nNo list of items was read: open the RFQ and add them.") . "\n\nOpen the RFQ tracker (Finance → RFQs) and press “Create quotation”: the items are copied into it."];
}
/** One email. Returns 'rfq' | 'po' | 'followup' | '' */
function rfq_handle_mail(array $acc, array $actor, array $st, array $m): string {
    $ex = isset($m['x']) ? rfq_extract($m['x']) : ['items' => [], 'source' => '', 'files' => []];
    $subj = (string)$m['subject']; $body = (string)$m['text']; $from = strtolower((string)$m['from_email']); $all = $subj . "\n" . $body . "\n" . implode(' ', $m['att_names'] ?? []); $norm = rfq_norm($all);
    // a purchase order for one of our open RFQs (its code appears in the mail, or in a file name)
    $open = all("SELECT * FROM rfqs WHERE status IN ('new','quoting','quoted') AND LENGTH(code)>=4 ORDER BY id DESC LIMIT 400"); $hit = null;
    foreach ($open as $r) { if (str_contains($norm, rfq_norm((string)$r['code']))) { $hit = $r; break; } }
    if ($hit && (preg_match(RFQ_PO_WORDS, $subj . ' ' . mb_substr($body, 0, 2000)) || !preg_match(RFQ_WORDS, $subj))) {
        $po = rfq_find_po($subj, $body) ?: ('PO-' . date('ymd')); $tid = null;   // a scan only tracks it: the task is made when someone reviews it and adds it
        $dd2 = preg_match('/(deliver(?:y|ed)?)[^.\n]{0,40}?(?:by|on|before|date|within|:)[^0-9A-Za-z]{0,6}(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}(?:st|nd|rd|th)?\s+(?:of\s+)?[A-Za-z]{3,9},?\s+\d{4})/i', mb_substr($body, 0, 4000), $mm) ? rfq_find_date('due by ' . $mm[2]) : null;
        if ($dd2) q('UPDATE rfqs SET delivery_due=? WHERE id=?', [$dd2, (int)$hit['id']]);
        q("UPDATE rfqs SET status='po_received', po_number=?, po_received_at=?, po_from=?, po_subject=?, po_files=?, po_task_id=? WHERE id=?", [mb_substr($po, 0, 80), $m['date'] ?: date('Y-m-d H:i:s'), mb_substr($m['from_email'], 0, 190), mb_substr($subj, 0, 300), mb_substr(implode(', ', $m['att_names'] ?? []), 0, 480) ?: null, $tid, (int)$hit['id']]);
        rfq_save_files((int)$hit['id'], 'po', $ex['files']); if ($ex['items'] && !$hit['items_json']) rfq_store_items((int)$hit['id'], $ex);
        if ($hit['task_id']) q("UPDATE tasks SET status='done', completed_at=NOW() WHERE id=? AND status<>'done'", [(int)$hit['task_id']]);
        rfq_event((int)$hit['id'], 'po', 'Purchase order ' . $po . ' received from ' . $m['from_email']); foreach (array_unique(array_filter([(int)$hit['created_by']])) as $n) notify($n, 'rfq_po', '📨 PO received for RFQ ' . $hit['code'], 'PO ' . $po, '#/finance/rfqs'); return 'po';
    }
    if (!preg_match(RFQ_WORDS, $subj . ' ' . mb_substr($body, 0, 1500) . ' ' . implode(' ', $m['att_names'] ?? []))) return '';
    $code = rfq_find_code($subj, $body); $src = 'email'; if ($code === null) { $code = rfq_next_code(); $src = 'generated'; }
    $dup = one('SELECT id FROM rfqs WHERE code=? AND (client_email=? OR client_email IS NULL) ORDER BY id DESC LIMIT 1', [$code, $from]);
    if ($dup) { rfq_event((int)$dup['id'], 'mail', 'Another email about this RFQ from ' . $m['from_email'] . ': ' . mb_substr($subj, 0, 120)); rfq_save_files((int)$dup['id'], 'rfq', $ex['files']); if ($ex['items'] && !one('SELECT items_json FROM rfqs WHERE id=?', [(int)$dup['id']])['items_json']) rfq_store_items((int)$dup['id'], $ex); return 'followup'; }
    $name = trim((string)($m['from_name'] ?? '')); $co = ia_company_for($from, $name, false); $client = $co['name'] ?? ($name !== '' ? $name : ucfirst(explode('.', explode('@', substr(strrchr($from, '@') ?: '@', 1))[0])[0]));
    $due = rfq_find_date($subj . "\n" . $body); $snip = mb_substr(trim(preg_replace('/\s+/', ' ', $body)), 0, 600);
    $desc = trim(preg_replace('/^(re|fw|fwd)\s*:\s*|\b(rfq|request for (quotation|quote))\b[\s#:.\-]*' . preg_quote((string)$code, '/') . '[\s:.\-]*/i', '', $subj)) ?: $subj;
    q('INSERT INTO rfqs (code,code_source,client_name,client_email,subject,description,buyer_details,snippet,received_at,due_date,msg_key,account_id,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', [mb_substr($code, 0, 80), $src, mb_substr($client, 0, 190), mb_substr($from, 0, 190), mb_substr($subj, 0, 300), mb_substr($desc, 0, 500), mb_substr($from, 0, 480), $snip, $m['date'] ?: date('Y-m-d H:i:s'), $due, $m['msg_key'], (int)$acc['id'], (int)$actor['id']]);
    $id = (int)db()->lastInsertId(); rfq_save_files($id, 'rfq', $ex['files']); rfq_store_items($id, $ex); if (!$ex['items']) rfq_event($id, 'items', 'No list of items could be read from the email or its files. Add the items in the tracker.');
    $itemsNote = $ex['items'] ? "\n\nItems requested (read from " . $ex['source'] . "):\n" . rfq_items_line($ex['items']) : "\n\nNo list of items could be read from the email or its files: open the RFQ and add them.";
    rfq_event($id, 'new', 'RFQ received from ' . $from . ' · code ' . $code . ($src === 'generated' ? ' (made by us)' : '')); return 'rfq';
}
function rfq_scan(array $acc, array $actor, int $days = 7, int $limit = 80): array {
    rfq_ensure(); $st = rfq_settings(); $allow = rfq_effective_allow((string)($st['allowed_senders'] ?? '')); $r = ['rfqs' => 0, 'pos' => 0, 'followups' => 0, 'looked_at' => 0, 'ignored' => [], 'ours' => 0];
    if (!rfq_allow_list($allow)) return $r + ['no_allowed' => true];   // nobody is allowed yet: nothing is read, nothing is kept
    $im = ia_imap($acc); $im->select('INBOX'); $since = date('d-M-Y', strtotime('-' . max(1, min(60, $days)) . ' days')); $uids = array_slice($im->search('SINCE ' . $since), -max(1, min(200, $limit))); $r['looked_at'] = count($uids);
    foreach (array_chunk(array_reverse($uids), 40) as $chunk) {
        try { $hh = $im->headers($chunk); } catch (Throwable $e) { error_log('RFQ headers: ' . $e->getMessage()); continue; }
        foreach ($chunk as $uid) {
            try { $hd = $hh[$uid] ?? null; if (!$hd || empty($hd['from'])) continue; $fe = strtolower((string)$hd['from'][0]['email']);
                if (rfq_is_ours($fe, (string)$acc['email'])) { $r['ours']++; continue; }   // an RFQ made by us is never tracked among the companies' RFQs
                if (!rfq_allowed($fe, $allow)) { $r['ignored'][$fe] = ($r['ignored'][$fe] ?? 0) + 1; continue; }   // not on the list: never opened, never saved
                $key = sha1('rfq|' . $acc['id'] . '|' . ($hd['message_id'] ?: 'INBOX' . $uid)); if (one('SELECT msg_key FROM rfq_msgs WHERE msg_key=?', [$key])) continue;
                $raw = $im->fetchRaw((int)$uid, 16000000); $x = mime_extract($raw); $h = $x['headers']; $subject = mime_decode_header($h['subject'] ?? ''); q('INSERT IGNORE INTO rfq_msgs (msg_key,kind) VALUES (?,?)', [$key, 'seen']);
                $why = ia_skip_reason($h, $fe, $subject, (string)$acc['email'], []); if ($why !== '') continue;   // automatic mail, our own team and ignored senders are skipped
                $res = rfq_handle_mail($acc, $actor, $st, ['subject' => $subject, 'text' => (string)$x['text'], 'from_email' => $fe, 'from_name' => (string)($hd['from'][0]['name'] ?? ''), 'date' => mime_date($h['date'] ?? ''), 'msg_key' => $key, 'att_names' => array_map(fn($a) => (string)$a['name'], $x['attachments'] ?? []), 'x' => $x]);
                if ($res) { q('UPDATE rfq_msgs SET kind=? WHERE msg_key=?', [$res, $key]); $r[$res === 'rfq' ? 'rfqs' : ($res === 'po' ? 'pos' : 'followups')]++; }
            } catch (Throwable $e) { error_log('RFQ scan: ' . $e->getMessage()); }
        }
    }
    arsort($r['ignored']); $r['ignored'] = array_slice($r['ignored'], 0, 12, true); q('UPDATE rfq_settings SET last_scan_at=NOW() WHERE id=1'); return $r;
}
/** The quotation made in Finance for an RFQ: matched by RFQ reference or by the action task. Marks "quoted" once it has been sent. */
function rfq_sync_quotes(): void {
    foreach (all("SELECT * FROM rfqs WHERE status IN ('new','quoting','quoted') ORDER BY id DESC LIMIT 300") as $r) {
        $d = one("SELECT id,number,doc_type,status,currency,updated_at FROM fin_docs WHERE doc_type IN ('commercial','proforma') AND status<>'void' AND (UPPER(REPLACE(REPLACE(REPLACE(REPLACE(rfq_ref,'-',''),'/',''),' ',''),'.',''))=? OR (task_id IS NOT NULL AND task_id=?)) ORDER BY (status IN ('sent','paid')) DESC, id DESC LIMIT 1", [rfq_norm((string)$r['code']), (int)($r['task_id'] ?: 0)]);
        if (!$d) continue; $tot = rfq_doc_total((int)$d['id']); $sent = in_array($d['status'], ['sent', 'paid'], true); $new = $sent ? 'quoted' : 'quoting';
        if ((int)$r['quote_doc_id'] !== (int)$d['id'] || $r['status'] !== $new || abs((float)$r['quote_total'] - $tot) > 0.004) {
            if (!$r['quote_doc_id'] || (int)$r['quote_doc_id'] !== (int)$d['id']) rfq_event((int)$r['id'], 'quote', 'Quotation ' . $d['number'] . ' created');
            q('UPDATE rfqs SET quote_doc_id=?, quote_number=?, quote_total=?, currency=?, status=?, quoted_at=IF(?=1 AND quoted_at IS NULL, NOW(), quoted_at) WHERE id=?', [(int)$d['id'], $d['number'], $tot, $d['currency'], $new, $sent ? 1 : 0, (int)$r['id']]);
            if ($sent && $r['status'] !== 'quoted') { rfq_event((int)$r['id'], 'quoted', 'Quotation ' . $d['number'] . ' sent'); if ($r['task_id']) q("UPDATE tasks SET status='done', completed_at=NOW() WHERE id=? AND status<>'done'", [(int)$r['task_id']]); } }
    }
}
/** Total of a quotation (lines that carry a note such as "As incurred" are shown but not counted; then discount and tax), the same arithmetic as the document itself. */
function rfq_doc_total(int $id): float {
    $d = one('SELECT discount,tax_rate FROM fin_docs WHERE id=?', [$id]); if (!$d) return 0.0; $sub = (float)(one("SELECT COALESCE(SUM(CASE WHEN COALESCE(amount_note,'')<>'' THEN 0 ELSE qty*unit_price END),0) s FROM fin_items WHERE doc_id=?", [$id])['s'] ?? 0);
    $net = $sub - min(max(0.0, (float)$d['discount']), $sub); return round($net + round($net * (float)$d['tax_rate'] / 100, 2), 2);
}
function rfq_cron(): string {
    try { rfq_ensure(); $st = rfq_settings(); if (empty($st['enabled'])) return 'RFQ tracker: off'; rfq_sync_quotes(); $ids = array_filter(array_map('intval', explode(',', (string)($st['mailbox_ids'] ?? '')))); if (!$ids) return 'RFQ tracker: no mailbox chosen'; $tot = ['rfqs' => 0, 'pos' => 0];
        foreach ($ids as $aid) { $acc = one('SELECT * FROM mail_accounts WHERE id=?', [$aid]); if (!$acc) continue; $actor = one('SELECT id,name,email,role FROM users WHERE id=?', [$acc['user_id']]); if (!$actor) continue; $r = rfq_scan($acc, $actor, 3, 80); $tot['rfqs'] += $r['rfqs']; $tot['pos'] += $r['pos']; }
        return 'RFQ tracker: ' . json_encode($tot); } catch (Throwable $e) { return 'RFQ tracker skipped: ' . $e->getMessage(); }
}

/** The Excel tracker in the layout Aerosub already uses: RFQ block, then PO block, grouped by client. */
const RFQ_LABEL = ['new' => 'Received', 'quoting' => 'Quotation in progress', 'quoted' => 'Submitted', 'revisited' => 'Revisited', 'on_hold' => 'On Hold', 'po_received' => 'PO received', 'delivered' => 'Delivered', 'paid' => 'PAID', 'lost' => 'Lost', 'closed' => 'Closed'];
/** RFQ year: when it was received (or entered). */
function rfq_year_sql(): string { return 'YEAR(COALESCE(received_at, created_at))'; }
/** The tracker as the company's own LIST_OF_RFQs_AND_POs template: one flat table per year (sheet named after the year), RFQ block on the left and PO block on the right. */
function rfq_export_xlsx(int $year = 0): string {
    $year = $year ?: (int)date('Y'); $hd = ['fill' => 'BFBFBF', 'color' => '000000', 'b' => true, 'h' => 'center', 'border' => 'thin', 'wrap' => true]; $cell = ['border' => 'thin', 'wrap' => true, 'v' => 'top']; $dt = ['border' => 'thin', 'v' => 'top', 'h' => 'center', 'fmt' => 'dd/mm/yyyy'];
    $rows = [1 => ['h' => 24, 'cells' => [1 => ['v' => 'RFP/RFQ/TENDERS', 's' => ['b' => true, 'sz' => 13]], 9 => ['v' => 'PURCHASE ORDER (PO)', 's' => ['b' => true, 'sz' => 13]]]]];
    $cols = ['S/N', 'COMPANY', 'RFQ NUMBER', 'DESCRIPTION', 'DATE RECEIVED', 'SUBMISSION DATE', 'STATUS', 'COMMENTS', 'PO NUMBER', 'DESCRIPTION', 'DATE RECEIVED', 'DELIVERY DUE DATE', 'ACTUAL DELIVERY DATE', 'STATUS', 'INVOICE STATUS', 'COMMENTS', 'PAYMENT STATUS', 'BUYER DETAILS'];
    $c = []; foreach ($cols as $i => $t) $c[$i + 1] = ['v' => $t, 's' => $hd]; $rows[2] = ['h' => 30, 'cells' => $c]; $r = 3; $n = 0;
    $d = fn($v) => $v ? ['v' => date('d/m/Y', strtotime((string)$v)), 's' => $dt] : ['v' => '', 's' => $cell]; $t = fn($v) => ['v' => (string)($v ?? ''), 's' => $cell];
    foreach (all('SELECT * FROM rfqs WHERE ' . rfq_year_sql() . '=? ORDER BY COALESCE(received_at, created_at), id', [$year]) as $x) {
        $n++; $po = $x['po_number'] !== null && $x['po_number'] !== '';
        $poSt = $po ? (in_array($x['status'], ['delivered', 'paid'], true) || $x['delivery_date'] ? 'Delivered' : 'PO received') : '';
        $rows[$r++] = ['cells' => [1 => ['v' => $n, 's' => $cell], 2 => $t($x['client_name']), 3 => $t($x['code']), 4 => $t($x['description'] ?: $x['subject']), 5 => $d($x['received_at']), 6 => $d($x['due_date'] ?: $x['quoted_at']), 7 => $t(RFQ_LABEL[$x['status']] ?? $x['status']), 8 => $t($x['notes']),
            9 => $t($x['po_number']), 10 => $t($po ? ($x['po_description'] ?: ($x['description'] ?: $x['subject'])) : ''), 11 => $d($x['po_received_at']), 12 => $d($x['delivery_due']), 13 => $d($x['delivery_date']), 14 => $t($poSt), 15 => $t($x['invoice_status']), 16 => $t($x['po_comments']), 17 => $t($x['status'] === 'paid' ? 'PAID' : $x['payment_status']), 18 => $t($x['buyer_details'])]];
    }
    return xlsx_write(['name' => (string)$year, 'cols' => [5, 22, 16, 44, 13, 13, 18, 30, 16, 36, 13, 14, 14, 14, 16, 28, 16, 34], 'rows' => $rows, 'merges' => [], 'landscape' => true, 'freeze' => 'C3']);
}
function rfq_cell_date($v): ?string {
    $v = trim((string)$v); if ($v === '') return null; if (is_numeric($v) && (float)$v > 30000 && (float)$v < 80000) return date('Y-m-d', (int)round(((float)$v - 25569) * 86400));
    if (preg_match('~^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})$~', $v, $m)) { $y = (int)$m[3] < 100 ? 2000 + (int)$m[3] : (int)$m[3]; return checkdate((int)$m[2], (int)$m[1], $y) ? sprintf('%04d-%02d-%02d', $y, (int)$m[2], (int)$m[1]) : null; }
    $t = strtotime($v); return $t ? date('Y-m-d', $t) : null;
}
/** Rows of the Excel tracker (first sheet): client heading rows, then one RFQ (and its PO) per row. Existing RFQ numbers for the same client are left alone. */
/** The company template: header row has COMPANY and RFQ NUMBER; one RFQ (and its PO) per row. Columns are found by their headings, so extra or moved columns do not matter. */
function rfq_import_flat(array $rows, array $u, int $hdr): array {
    rfq_ensure(); $map = []; $seen = [];
    foreach ($rows[$hdr] as $i => $h) { $k = strtoupper(trim(preg_replace('/\s+/', ' ', (string)$h))); if ($k === '') continue; $seen[$k] = ($seen[$k] ?? 0) + 1; $map[$k . '#' . $seen[$k]] = $i; }
    $col = fn(string $k, int $nth = 1) => $map[$k . '#' . $nth] ?? null; $get = function (array $row, ?int $c) { return $c === null ? '' : trim((string)($row[$c] ?? '')); };
    $cC = $col('COMPANY'); $cR = $col('RFQ NUMBER'); $added = 0; $skipped = 0; $clients = [];
    foreach (array_slice($rows, $hdr + 1, null, true) as $row) {
        $client = trim(preg_replace('/\s+/', ' ', $get($row, $cC))); $code = preg_replace('/\.0$/', '', $get($row, $cR)); if ($client === '' || $code === '') continue;
        if (one('SELECT id FROM rfqs WHERE code=? AND client_name=?', [$code, $client])) { $skipped++; continue; }
        $desc = $get($row, $col('DESCRIPTION', 1)); $rec = rfq_cell_date($get($row, $col('DATE RECEIVED', 1))); $sub = rfq_cell_date($get($row, $col('SUBMISSION DATE'))); $stt = strtolower($get($row, $col('STATUS', 1))); $notes = $get($row, $col('COMMENTS', 1));
        $po = $get($row, $col('PO NUMBER')); $poDesc = $get($row, $col('DESCRIPTION', 2)); $poRec = rfq_cell_date($get($row, $col('DATE RECEIVED', 2))); $due = rfq_cell_date($get($row, $col('DELIVERY DUE DATE'))); $act = rfq_cell_date($get($row, $col('ACTUAL DELIVERY DATE')));
        $pst = strtolower($get($row, $col('STATUS', 2))); $inv = $get($row, $col('INVOICE STATUS')); $pc = $get($row, $col('COMMENTS', 2)); $pay = $get($row, $col('PAYMENT STATUS')); $buyer = $get($row, $col('BUYER DETAILS'));
        $status = str_contains($stt, 'revis') ? 'revisited' : (str_contains($stt, 'hold') ? 'on_hold' : (str_contains($stt, 'submit') ? 'quoted' : (str_contains($stt, 'cancel') || str_contains($stt, 'lost') || str_contains($stt, 'nil') ? 'lost' : (str_contains($stt, 'award') || str_contains($stt, 'won') ? 'po_received' : 'new'))));
        if ($po !== '') $status = 'po_received'; if (str_contains($pst, 'deliver') || $act) $status = 'delivered'; if (strtolower($pay) === 'paid') $status = 'paid';
        $first = trim(explode(',', $buyer)[0]);
        q('INSERT INTO rfqs (code,code_source,client_name,client_email,subject,description,buyer_details,received_at,due_date,status,notes,po_number,po_description,po_received_at,delivery_due,delivery_date,invoice_status,po_comments,payment_status,paid_at,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
          [mb_substr($code, 0, 80), 'manual', mb_substr($client, 0, 190), filter_var($first, FILTER_VALIDATE_EMAIL) ?: null, mb_substr($desc, 0, 300), mb_substr($desc, 0, 500), mb_substr($buyer, 0, 480) ?: null, $rec, $sub, $status, $notes ?: null, $po !== '' ? mb_substr($po, 0, 80) : null, $po !== '' ? mb_substr($poDesc, 0, 500) : null, $poRec, $due, $act, mb_substr($inv, 0, 30) ?: null, $pc ?: null, strtolower($pay) === 'paid' ? null : (mb_substr($pay, 0, 30) ?: null), strtolower($pay) === 'paid' ? ($act ?: date('Y-m-d')) : null, (int)$u['id']]);
        rfq_event((int)db()->lastInsertId(), 'new', 'Imported from the Excel tracker', (int)$u['id']); $added++; $clients[$client] = 1;
    }
    return ['added' => $added, 'skipped' => $skipped, 'clients' => count($clients)];
}
function rfq_import_rows(array $rows, array $u): array {
    rfq_ensure(); $client = ''; $added = 0; $skipped = 0; $clients = [];
    foreach (array_slice($rows, 0, 12, true) as $hi => $hr) { $hs = array_map(fn($v) => strtoupper(trim((string)$v)), (array)$hr); if (in_array('COMPANY', $hs, true) && in_array('RFQ NUMBER', $hs, true)) return rfq_import_flat($rows, $u, $hi); }   // the company template
    foreach ($rows as $row) {
        $a = trim((string)($row[0] ?? '')); $b = trim((string)($row[1] ?? '')); $c = trim((string)($row[2] ?? ''));
        if ($a === '' && $b !== '' && $c === '' && !is_numeric($b)) { $client = trim(preg_replace('/\s+/', ' ', $b)); continue; }
        if ($a === '' || !is_numeric($a) || $b === '' || $client === '') continue; $code = preg_replace('/\.0$/', '', $b); if (one('SELECT id FROM rfqs WHERE code=? AND client_name=?', [$code, $client])) { $skipped++; continue; }
        $stt = strtolower(trim((string)($row[5] ?? ''))); $po = trim((string)($row[7] ?? '')); $del = rfq_cell_date($row[11] ?? ''); $mst = strtolower(trim((string)($row[12] ?? ''))); $pay = strtolower(trim((string)($row[15] ?? '')));
        $status = str_contains($stt, 'revis') ? 'revisited' : (str_contains($stt, 'hold') ? 'on_hold' : (str_contains($stt, 'submit') ? 'quoted' : (str_contains($stt, 'cancel') || str_contains($stt, 'lost') ? 'lost' : 'new')));
        if ($po !== '') $status = 'po_received'; if ($mst === 'delivered' || $del) $status = 'delivered'; if ($pay === 'paid') $status = 'paid';
        $buyer = trim((string)($row[16] ?? '')); $first = trim(explode(',', $buyer)[0]);
        q('INSERT INTO rfqs (code,code_source,client_name,client_email,subject,description,buyer_details,received_at,due_date,status,notes,po_number,po_description,po_received_at,delivery_due,delivery_date,invoice_status,po_comments,paid_at,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
          [mb_substr($code, 0, 80), 'manual', mb_substr($client, 0, 190), filter_var($first, FILTER_VALIDATE_EMAIL) ?: null, mb_substr((string)$row[2], 0, 300), mb_substr((string)$row[2], 0, 500), mb_substr($buyer, 0, 480) ?: null, rfq_cell_date($row[3] ?? ''), rfq_cell_date($row[4] ?? ''), $status, trim((string)($row[6] ?? '')) ?: null, $po !== '' ? mb_substr($po, 0, 80) : null, $po !== '' ? mb_substr((string)($row[8] ?? ''), 0, 500) : null, rfq_cell_date($row[9] ?? ''), rfq_cell_date($row[10] ?? ''), $del, trim((string)($row[13] ?? '')) ?: null, trim((string)($row[14] ?? '')) ?: null, null, (int)$u['id']]);
        rfq_event((int)db()->lastInsertId(), 'new', 'Imported from the Excel tracker', (int)$u['id']); $added++; $clients[$client] = 1;
    }
    return ['added' => $added, 'skipped' => $skipped, 'clients' => count($clients)];
}
/** The delivery note as an editable Word file on the Aerosub letterhead (same layout as AEROSUB_DELIVERY_NOTE_TEMPLATE). */
function dn_docx(array $d): array {
    $e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); $items = json_decode((string)$d['items'], true) ?: []; $rows = ''; foreach ($items as $i => $it) $rows .= '<tr><td>' . ($i + 1) . '</td><td>' . $e($it['description']) . '</td><td>' . $e(rtrim(rtrim(number_format((float)$it['qty'], 2, '.', ''), '0'), '.') . ' ' . ($it['unit'] ?? '')) . '</td></tr>';
    $html = '<h2 style="text-align:center">DELIVERY NOTE</h2><p style="text-align:right">' . $e(date('F j, Y', strtotime((string)($d['delivery_date'] ?: 'today')))) . '</p>' . ($d['po_number'] ? '<p><b>PO NUMBER : </b>' . $e($d['po_number']) . '</p>' : '') . '<p><b>DELIVERED TO :</b></p><table><tr><td><b>' . $e($d['client_name']) . '</b><br>' . nl2br($e(trim((string)($d['delivery_address'] ?: $d['client_address'])))) . '</td></tr></table>'
        . '<p></p><table><tr><th>S/N</th><th>DESCRIPTION</th><th>QTY/UoM</th></tr>' . $rows . '</table><p>Goods received in good condition</p><p></p><table><tr><td>Name: [' . $e($d['client_name']) . ']<br><br><br>Signature: ______________________</td><td>Name: [Aerosub Solutions Ltd]' . ($d['signed_at'] ? '<br>Signed in Aerosub Office on ' . $e(date('j M Y', strtotime((string)$d['signed_at']))) : '<br>') . '<br><br>Signature: ______________________</td></tr></table>';
    $art = is_file(dirname(__DIR__, 2) . '/assets/img/letterhead-aerosub.png') ? ['data' => (string)file_get_contents(dirname(__DIR__, 2) . '/assets/img/letterhead-aerosub.png'), 'mime' => 'image/png'] : null;
    return [ltr_docx('Delivery note ' . $d['number'], $html, $art, [52.0, 44.0, 22.0, 22.0]), $d['number'] . '.docx'];
}

/* ---------------- routes ---------------- */
if (!isset($seg[0]) || $seg[0] !== 'finance' || !isset($u)) return;
require_once __DIR__ . '/taskfiles.php'; rfq_ensure();
if (!$fin) fail('The RFQ tracker is for the finance team', 403);
function rfq_dto(array $r): array {
    return ['id' => (int)$r['id'], 'code' => $r['code'], 'code_source' => $r['code_source'], 'client_name' => $r['client_name'], 'client_email' => $r['client_email'], 'subject' => $r['subject'], 'received_at' => $r['received_at'], 'due_date' => $r['due_date'], 'status' => $r['status'], 'task_id' => $r['task_id'] ? (int)$r['task_id'] : null, 'po_task_id' => !empty($r['po_task_id']) ? (int)$r['po_task_id'] : null,
        'quote_doc_id' => $r['quote_doc_id'] ? (int)$r['quote_doc_id'] : null, 'quote_number' => $r['quote_number'], 'quote_total' => $r['quote_total'] !== null ? (float)$r['quote_total'] : null, 'currency' => $r['currency'], 'quoted_at' => $r['quoted_at'], 'po_number' => $r['po_number'], 'po_received_at' => $r['po_received_at'], 'po_from' => $r['po_from'], 'po_files' => $r['po_files'],
        'items' => json_decode((string)($r['items_json'] ?? ''), true) ?: [], 'items_source' => $r['items_source'] ?? null, 'description' => $r['description'] ?? null, 'po_description' => $r['po_description'] ?? null, 'delivery_due' => $r['delivery_due'] ?? null, 'invoice_status' => $r['invoice_status'] ?? null, 'payment_status' => $r['status'] === 'paid' ? 'PAID' : ($r['payment_status'] ?? null), 'year' => (int)substr((string)($r['received_at'] ?: $r['created_at']), 0, 4), 'po_comments' => $r['po_comments'] ?? null, 'buyer_details' => $r['buyer_details'] ?? null, 'delivery_date' => $r['delivery_date'], 'paid_at' => $r['paid_at'], 'paid_amount' => $r['paid_amount'] !== null ? (float)$r['paid_amount'] : null, 'pay_ref' => $r['pay_ref'], 'notes' => $r['notes'], 'updated_at' => $r['updated_at']];
}
function dn_dto(array $d): array {
    return ['id' => (int)$d['id'], 'number' => $d['number'], 'rfq_id' => $d['rfq_id'] ? (int)$d['rfq_id'] : null, 'rfq_code' => $d['rfq_code'], 'client_name' => $d['client_name'], 'client_address' => $d['client_address'], 'po_number' => $d['po_number'], 'delivery_date' => $d['delivery_date'], 'delivery_address' => $d['delivery_address'], 'items' => json_decode((string)$d['items'], true) ?: [], 'notes' => $d['notes'],
        'signed' => $d['signed_at'] !== null, 'signed_by' => $d['signed_by_name'] ?? null, 'signed_at' => $d['signed_at'], 'signature' => $d['signature'], 'printed_at' => $d['printed_at'], 'created_by' => $d['created_by_name'] ?? null, 'created_at' => $d['created_at']];
}
if ($sub === 'rfqs') {
    $rid = isset($seg[2]) && ctype_digit($seg[2]) ? (int)$seg[2] : 0; $act = $rid ? ($seg[3] ?? '') : ($seg[2] ?? '');
    if ($act === 'settings') {
        $st = rfq_settings();
        if ($method === 'GET') { $mine = all('SELECT id,email FROM mail_accounts WHERE user_id=? ORDER BY id', [$uid]); $sel = array_filter(array_map('intval', explode(',', (string)($st['mailbox_ids'] ?? ''))));
            out(['enabled' => (bool)$st['enabled'], 'mailboxes' => array_map(fn($a) => ['id' => (int)$a['id'], 'email' => $a['email'], 'on' => in_array((int)$a['id'], $sel, true)], $mine), 'others' => all('SELECT id,email FROM mail_accounts WHERE id IN (' . ($sel ? implode(',', $sel) : '0') . ') AND user_id<>?', [$uid]), 'assign_user_id' => $st['assign_user_id'] ? (int)$st['assign_user_id'] : null, 'allowed_senders' => implode("\n", rfq_allow_list($st['allowed_senders'] ?? '')), 'designated' => ['companies' => all('SELECT id,name FROM companies WHERE rfq_ok=1 ORDER BY name LIMIT 100'), 'contacts' => all('SELECT id,name,email FROM contacts WHERE rfq_ok=1 AND vendor_id IS NULL ORDER BY name LIMIT 100')],
                'finance_people' => all("SELECT u.id,u.name FROM users u WHERE u.active=1 AND (u.role='super_admin' OR u.department_id=(SELECT id FROM departments WHERE name='Finance' LIMIT 1)) ORDER BY u.name"), 'last_scan_at' => $st['last_scan_at']]); }
        if (!in_array($role, ['super_admin', 'manager'], true) && !can_finance($u)) fail('Not allowed', 403);
        if ($method === 'PUT') { $mine = array_map('intval', array_column(all('SELECT id FROM mail_accounts WHERE user_id=?', [$uid]), 'id')); $keep = array_filter(array_map('intval', explode(',', (string)($st['mailbox_ids'] ?? ''))), fn($i) => !in_array($i, $mine, true)); $on = array_values(array_intersect(array_map('intval', (array)($b['mailbox_ids'] ?? [])), $mine));
            q('UPDATE rfq_settings SET enabled=?, mailbox_ids=?, assign_user_id=? WHERE id=1', [(int)!empty($b['enabled']), implode(',', array_unique(array_merge($keep, $on))) ?: null, !empty($b['assign_user_id']) ? (int)$b['assign_user_id'] : null]); if (array_key_exists('allowed_senders', $b)) q('UPDATE rfq_settings SET allowed_senders=? WHERE id=1', [implode("\n", rfq_allow_list((string)$b['allowed_senders'])) ?: null]); out(['ok' => true]); }
        fail('Not found', 404);
    }
    if ($act === 'export' && $method === 'GET') { rfq_sync_quotes(); require_once __DIR__ . '/xlsx.php'; $bin = rfq_export_xlsx((int)($_GET['year'] ?? 0)); header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); header('Content-Disposition: attachment; filename="LIST_OF_RFQs_AND_POs_' . ((int)($_GET['year'] ?? 0) ?: date('Y')) . '.xlsx"'); header('Content-Length: ' . strlen($bin)); header('Cache-Control: private, no-store'); echo $bin; exit; }
    if ($act === 'import' && $method === 'POST') { require_once __DIR__ . '/xlsx.php'; $data = base64_decode((string)($b['data'] ?? ''), true); if ($data === false || strlen($data) < 200 || strlen($data) > 6 * 1048576) fail('Choose the Excel file (up to 6 MB)'); $tmp = tempnam(sys_get_temp_dir(), 'rfq'); file_put_contents($tmp, $data);
        try { $r = rfq_import_rows(xlsx_read($tmp), $u); } catch (Throwable $e) { @unlink($tmp); fail('That file could not be read: ' . mb_substr($e->getMessage(), 0, 120)); } @unlink($tmp); log_act($uid, 'rfq_import', $r['added'] . ' added'); out(['ok' => true] + $r); }
    if ($act === 'scan' && $method === 'POST') {
        rfq_sync_quotes(); $st = rfq_settings(); $ids = array_filter(array_map('intval', explode(',', (string)($st['mailbox_ids'] ?? '')))); $acc = [];
        foreach ($ids as $i) { $a = one('SELECT * FROM mail_accounts WHERE id=?', [$i]); if ($a && (int)$a['user_id'] === $uid) $acc[] = $a; } if (!$acc) { $a = one('SELECT * FROM mail_accounts WHERE user_id=? ORDER BY id LIMIT 1', [$uid]); if ($a) $acc[] = $a; }
        if (!$acc) fail('Connect the operations@ mailbox in the Mail tab first, then choose it in the tracker settings.', 409); $tot = ['rfqs' => 0, 'pos' => 0, 'followups' => 0, 'looked_at' => 0, 'ours' => 0]; $ign = []; $none = false;
        try { foreach ($acc as $a) { $r = rfq_scan($a, $u, (int)($b['days'] ?? 14), (int)($b['limit'] ?? 100)); foreach (['rfqs', 'pos', 'followups', 'looked_at', 'ours'] as $k) $tot[$k] += $r[$k]; foreach ($r['ignored'] as $e => $n) $ign[$e] = ($ign[$e] ?? 0) + $n; if (!empty($r['no_allowed'])) $none = true; } } catch (MailError $e) { fail($e->getMessage(), 502); }
        if ($none) fail('Nobody is allowed yet. Choose the customers whose RFQs and POs are tracked in ⚙ Mailbox → Who can send RFQs (or type their addresses under Allowed senders). Nothing else is read.', 409);
        arsort($ign); out(['ok' => true, 'ignored' => array_slice($ign, 0, 12, true)] + $tot);
    }
    if ($method === 'GET' && !$rid) {
        rfq_sync_quotes(); $w = '1=1'; $p = []; if (!empty($_GET['status']) && $_GET['status'] === 'open') { $w .= " AND status IN ('new','quoting','quoted','revisited','on_hold','po_received','delivered')"; } elseif (!empty($_GET['status']) && in_array($_GET['status'], ['new', 'quoting', 'quoted', 'revisited', 'on_hold', 'po_received', 'delivered', 'paid', 'lost', 'closed'], true)) { $w .= ' AND status=?'; $p[] = $_GET['status']; }
        if (!empty($_GET['q'])) { $w .= ' AND (code LIKE ? OR client_name LIKE ? OR po_number LIKE ? OR quote_number LIKE ? OR subject LIKE ?)'; $qq = '%' . fx_s($_GET['q'], 60) . '%'; array_push($p, $qq, $qq, $qq, $qq, $qq); }
        $yr = (int)($_GET['year'] ?? 0); if ($yr) { $w .= ' AND ' . rfq_year_sql() . '=?'; $p[] = $yr; } if (!empty($_GET['company'])) { $w .= ' AND client_name=?'; $p[] = fx_s($_GET['company'], 190); }
        $sorts = ['code' => 'code', 'company' => 'client_name', 'received' => 'COALESCE(received_at,created_at)', 'submission' => 'due_date', 'status' => 'status', 'po' => 'po_number', 'po_received' => 'po_received_at', 'delivery_due' => 'delivery_due', 'delivered' => 'delivery_date', 'invoice' => 'invoice_status', 'payment' => 'payment_status', 'value' => 'quote_total', 'updated' => 'updated_at']; $sk = $sorts[(string)($_GET['sort'] ?? '')] ?? 'COALESCE(received_at,created_at)'; $dir = (($_GET['dir'] ?? 'desc') === 'asc') ? 'ASC' : 'DESC';
        $rows = all("SELECT * FROM rfqs WHERE $w ORDER BY $sk IS NULL, $sk $dir, id $dir LIMIT 2000", $p);
        $years = all('SELECT ' . rfq_year_sql() . ' y, COUNT(*) n FROM rfqs GROUP BY y ORDER BY y DESC'); $companies = array_column(all('SELECT DISTINCT client_name FROM rfqs ORDER BY client_name LIMIT 300'), 'client_name');
        foreach (all("SELECT id,client_email FROM rfqs WHERE status='new' AND msg_key IS NOT NULL AND quote_number IS NULL AND po_number IS NULL AND client_email IS NOT NULL LIMIT 300") as $own1) if (rfq_is_ours((string)$own1['client_email'], '')) { q('DELETE FROM rfq_files WHERE rfq_id=?', [$own1['id']]); q('DELETE FROM rfq_events WHERE rfq_id=?', [$own1['id']]); q('DELETE FROM rfqs WHERE id=?', [$own1['id']]); }   // an RFQ that was made by us is not tracked
        $cnt = array_column(all('SELECT status, COUNT(*) n FROM rfqs' . ($yr ? ' WHERE ' . rfq_year_sql() . '=' . $yr : '') . ' GROUP BY status'), 'n', 'status'); $sales = one("SELECT COUNT(*) n, COALESCE(SUM(paid_amount),0) s FROM rfqs WHERE status='paid'"); $month = one("SELECT COALESCE(SUM(paid_amount),0) s FROM rfqs WHERE status='paid' AND paid_at >= ?", [date('Y-m-01')]);
        out(['rfqs' => array_map('rfq_dto', $rows), 'years' => array_map(fn($y) => ['year' => (int)$y['y'], 'n' => (int)$y['n']], $years), 'companies' => $companies, 'year' => $yr, 'counts' => $cnt, 'sales' => ['count' => (int)$sales['n'], 'total' => (float)$sales['s'], 'month' => (float)$month['s']], 'quoted_open' => (float)(one("SELECT COALESCE(SUM(quote_total),0) s FROM rfqs WHERE status IN ('quoted','po_received','delivered')")['s'] ?? 0)]);
    }
    if ($method === 'POST' && !$rid) {
        $client = fx_s($b['client_name'] ?? '', 190); if (!$client) fail('Who is the RFQ from?'); if (rfq_is_ours((string)fx_s($b['client_email'] ?? '', 190), '')) fail('That is one of our own addresses. The tracker is for RFQs that companies send us.'); $own = one('SELECT company_name FROM fin_settings WHERE id=1'); if ($own && trim((string)$own['company_name']) !== '' && strcasecmp(trim($client), trim((string)$own['company_name'])) === 0) fail('The RFQ must be from a client company, not from us.'); $code = fx_s($b['code'] ?? '', 80); $src = $code ? 'manual' : 'generated'; $code = $code ?: rfq_next_code(); $due = $b['due_date'] ?? null; $due = $due && strtotime((string)$due) ? date('Y-m-d', strtotime((string)$due)) : null;
        q('INSERT INTO rfqs (code,code_source,client_name,client_email,subject,received_at,due_date,notes,created_by) VALUES (?,?,?,?,?,NOW(),?,?,?)', [$code, $src, $client, fx_s($b['client_email'] ?? '', 190), fx_s($b['subject'] ?? '', 300), $due, fx_s($b['notes'] ?? '', 2000), $uid]); $id = (int)db()->lastInsertId(); $st = rfq_settings();
        $tid = rfq_task($id, 'Create proforma / quotation: ' . $client . ' (RFQ ' . $code . ')', "RFQ added by " . $u['name'] . ".\nRFQ code: " . $code . "\nOpen the RFQ tracker and press “Create quotation”.", $due, $st, $u, true); q('UPDATE rfqs SET task_id=? WHERE id=?', [$tid, $id]); rfq_event($id, 'new', 'Added by ' . $u['name'], $uid); out(['ok' => true, 'id' => $id], 201);
    }
    $r = $rid ? one('SELECT * FROM rfqs WHERE id=?', [$rid]) : null; if (!$r) fail('Not found', 404);
    if ($method === 'GET' && $act === '') { rfq_sync_quotes(); $r = one('SELECT * FROM rfqs WHERE id=?', [$rid]); out(['rfq' => rfq_dto($r), 'files' => all('SELECT id,kind,name,size,created_at FROM rfq_files WHERE rfq_id=? ORDER BY id', [$rid]), 'events' => all('SELECT e.kind,e.text,e.at,u.name AS by_name FROM rfq_events e LEFT JOIN users u ON u.id=e.user_id WHERE e.rfq_id=? ORDER BY e.id DESC LIMIT 60', [$rid]), 'deliveries' => array_map('dn_dto', all('SELECT d.*, u.name AS signed_by_name FROM delivery_notes d LEFT JOIN users u ON u.id=d.signed_by WHERE d.rfq_id=? ORDER BY d.id DESC', [$rid]))]); }
    if ($method === 'PATCH' && $act === '') {
        $f = []; $p = []; foreach (['client_name' => 190, 'client_email' => 190, 'subject' => 300, 'notes' => 2000, 'code' => 80, 'description' => 500, 'po_description' => 500, 'po_comments' => 2000, 'buyer_details' => 480, 'invoice_status' => 30, 'po_number' => 80, 'payment_status' => 30] as $k => $n) if (array_key_exists($k, $b)) { $v = fx_s($b[$k], $n); if ($k === 'code' && !$v) continue; $f[] = "$k=?"; $p[] = $v; }
        foreach (['delivery_due', 'delivery_date', 'paid_at'] as $dk) if (array_key_exists($dk, $b)) { $f[] = "$dk=?"; $p[] = $b[$dk] && strtotime((string)$b[$dk]) ? date('Y-m-d', strtotime((string)$b[$dk])) : null; }
        foreach (['received_at', 'po_received_at'] as $dk) if (array_key_exists($dk, $b)) { $f[] = "$dk=?"; $p[] = $b[$dk] && strtotime((string)$b[$dk]) ? date('Y-m-d', strtotime((string)$b[$dk])) . ' 09:00:00' : null; }
        if (array_key_exists('due_date', $b)) { $f[] = 'due_date=?'; $p[] = $b['due_date'] && strtotime((string)$b['due_date']) ? date('Y-m-d', strtotime((string)$b['due_date'])) : null; }
        if (!empty($b['status']) && in_array($b['status'], ['lost', 'closed', 'new', 'quoting', 'quoted', 'revisited', 'on_hold', 'po_received', 'delivered'], true)) { $f[] = 'status=?'; $p[] = $b['status']; rfq_event($rid, 'status', 'Marked ' . $b['status'] . ' by ' . $u['name'], $uid); }
        if (isset($b['payment_status']) && strtoupper(trim((string)$b['payment_status'])) === 'PAID') { $f[] = "status='paid'"; $f[] = 'paid_at=COALESCE(paid_at,CURDATE())'; }   // typing PAID in the sheet records the sale
        if ($f) { $p[] = $rid; q('UPDATE rfqs SET ' . implode(',', $f) . ' WHERE id=?', $p); } out(['ok' => true]);
    }
    if ($method === 'POST' && $act === 'items') { $it = []; foreach (array_slice((array)($b['items'] ?? []), 0, 100) as $i) { $dsc = fx_s($i['description'] ?? '', 500); if (!$dsc) continue; $it[] = ['description' => $dsc, 'qty' => fx_num($i['qty'] ?? 1, 1), 'unit' => fx_s($i['unit'] ?? '', 30) ?? '']; }
        q('UPDATE rfqs SET items_json=?, items_source=? WHERE id=?', [$it ? json_encode($it, JSON_UNESCAPED_UNICODE) : null, $it ? ($r['items_source'] ?: 'typed in by ' . $u['name']) : null, $rid]); rfq_event($rid, 'items', count($it) . ' item(s) saved by ' . $u['name'], $uid); out(['ok' => true, 'count' => count($it)]); }
    if ($method === 'GET' && $act === 'file') { $f = one('SELECT * FROM rfq_files WHERE id=? AND rfq_id=?', [(int)($seg[4] ?? 0), $rid]); if (!$f) fail('Not found', 404); $pth = rfq_dir() . '/' . preg_replace('/[^a-f0-9]/', '', (string)$f['path']); if (!is_file($pth)) fail('The file is no longer on the server', 404);
        header('Content-Type: application/octet-stream'); header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, no-store'); header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]+/', '_', (string)$f['name']) . '"; filename*=UTF-8\'\'' . rawurlencode((string)$f['name'])); header('Content-Length: ' . filesize($pth)); readfile($pth); exit; }
    if ($method === 'POST' && $act === 'task') {   // reviewed: this RFQ becomes the reviewer's own task (share it from the task if others should help)
        $col = $r['status'] === 'po_received' ? 'po_task_id' : 'task_id'; if ($r[$col] && one('SELECT id FROM tasks WHERE id=?', [(int)$r[$col]])) out(['ok' => true, 'task_id' => (int)$r[$col], 'existing' => true]);
        [$ttl, $tdesc] = rfq_task_text($r); $tid = rfq_task($rid, $ttl, $tdesc, $r['due_date'] ?: null, rfq_settings(), $u, true); q("UPDATE rfqs SET $col=? WHERE id=?", [$tid, $rid]); rfq_event($rid, 'task', 'Added to the tasks of ' . $u['name'], $uid); out(['ok' => true, 'task_id' => $tid]); }
    if ($method === 'POST' && $act === 'po') { $po = fx_s($b['po_number'] ?? '', 80); if (!$po) fail('Type the PO number'); q("UPDATE rfqs SET status='po_received', po_number=?, po_received_at=NOW() WHERE id=?", [$po, $rid]); rfq_event($rid, 'po', 'PO ' . $po . ' recorded by ' . $u['name'], $uid); out(['ok' => true]); }
    if ($method === 'POST' && $act === 'delivery') {
        $items = []; foreach (array_slice((array)($b['items'] ?? []), 0, 100) as $i) { $dsc = fx_s($i['description'] ?? '', 500); if (!$dsc) continue; $items[] = ['description' => $dsc, 'qty' => fx_num($i['qty'] ?? 1, 1), 'unit' => fx_s($i['unit'] ?? '', 30)]; }
        if (!$items && $r['quote_doc_id']) { $q = fx_doc((int)$r['quote_doc_id']); foreach (($q['items'] ?? []) as $i) { if (trim((string)$i['description']) === '') continue; $items[] = ['description' => (string)$i['description'], 'qty' => (float)$i['qty'], 'unit' => (string)($i['unit'] ?? '')]; } }
        if (!$items && $r['items_json']) foreach ((array)json_decode((string)$r['items_json'], true) as $i) $items[] = ['description' => (string)$i['description'], 'qty' => (float)$i['qty'], 'unit' => (string)($i['unit'] ?? '')];
        if (!$items) fail('Add what is being delivered (or create the quotation first so its lines can be used)');
        $dd = $b['delivery_date'] ?? null; $dd = $dd && strtotime((string)$dd) ? date('Y-m-d', strtotime((string)$dd)) : date('Y-m-d'); $n = (int)(one('SELECT COUNT(*) n FROM delivery_notes WHERE number LIKE ?', ['DN-' . date('Y') . '-%'])['n'] ?? 0) + 1; do { $num = 'DN-' . date('Y') . '-' . str_pad((string)$n++, 4, '0', STR_PAD_LEFT); } while (one('SELECT id FROM delivery_notes WHERE number=?', [$num]));
        $q = $r['quote_doc_id'] ? fx_doc((int)$r['quote_doc_id']) : null;
        q('INSERT INTO delivery_notes (number,rfq_id,quote_doc_id,client_name,client_address,po_number,rfq_code,delivery_date,delivery_address,items,notes,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', [$num, $rid, $r['quote_doc_id'] ?: null, $r['client_name'], fx_s($b['client_address'] ?? ($q['client_address'] ?? ''), 800), $r['po_number'], $r['code'], $dd, fx_s($b['delivery_address'] ?? ($q['ship_to'] ?? ''), 500), json_encode($items, JSON_UNESCAPED_UNICODE), fx_s($b['notes'] ?? '', 1000), $uid]);
        $id = (int)db()->lastInsertId(); q("UPDATE rfqs SET delivery_date=?, status=IF(status IN ('paid','lost','closed'), status, 'delivered') WHERE id=?", [$dd, $rid]); if ($r['po_task_id']) q("UPDATE tasks SET status='done', completed_at=NOW() WHERE id=? AND status<>'done'", [(int)$r['po_task_id']]);
        rfq_event($rid, 'delivery', 'Delivery note ' . $num . ' created · delivery date ' . $dd, $uid); out(['ok' => true, 'id' => $id, 'number' => $num], 201);
    }
    if ($method === 'POST' && $act === 'payment') {
        $dn = one('SELECT id,printed_at FROM delivery_notes WHERE rfq_id=? AND printed_at IS NOT NULL ORDER BY id DESC LIMIT 1', [$rid]); if (!$dn) fail('Print the delivery note first (for the client to sign), then confirm the payment here.', 409);
        $amt = fx_num($b['amount'] ?? ($r['quote_total'] ?? 0)); if ($amt <= 0) fail('Type the amount received'); $dt = $b['date'] ?? null; $dt = $dt && strtotime((string)$dt) ? date('Y-m-d', strtotime((string)$dt)) : date('Y-m-d');
        q("UPDATE rfqs SET status='paid', paid_at=?, paid_amount=?, pay_ref=? WHERE id=?", [$dt, $amt, fx_s($b['reference'] ?? '', 120), $rid]); rfq_event($rid, 'paid', 'Payment confirmed: ' . number_format($amt, 2) . ' ' . ($r['currency'] ?: '') . ' on ' . $dt . ' · sale recorded', $uid); log_act($uid, 'rfq_sale', $r['code'] . ' ' . $amt); out(['ok' => true]);
    }
    fail('Not found', 404);
}
if ($sub === 'delivery' && !isset($seg[2]) && $method === 'GET') {   // the Delivery notes tab: every note, newest first
    $w = ['1=1']; $p = []; $stt = (string)($_GET['status'] ?? ''); $qq = trim((string)($_GET['q'] ?? ''));
    if ($stt === 'unsigned') $w[] = 'd.signed_at IS NULL'; elseif ($stt === 'signed') $w[] = 'd.signed_at IS NOT NULL AND d.printed_at IS NULL'; elseif ($stt === 'printed') $w[] = 'd.printed_at IS NOT NULL AND (r.status IS NULL OR r.status<>\'paid\')'; elseif ($stt === 'paid') $w[] = "r.status='paid'";
    if ($qq !== '') { $lk = '%' . str_replace(['%', '_'], ['\\%', '\\_'], mb_substr($qq, 0, 80)) . '%'; $w[] = '(d.number LIKE ? OR d.client_name LIKE ? OR d.rfq_code LIKE ? OR d.po_number LIKE ?)'; array_push($p, $lk, $lk, $lk, $lk); }
    $rows = all('SELECT d.*, u.name AS signed_by_name, c.name AS created_by_name, r.status AS rfq_status, r.paid_at AS rfq_paid_at, r.paid_amount AS rfq_paid_amount FROM delivery_notes d LEFT JOIN users u ON u.id=d.signed_by LEFT JOIN users c ON c.id=d.created_by LEFT JOIN rfqs r ON r.id=d.rfq_id WHERE ' . implode(' AND ', $w) . ' ORDER BY d.id DESC LIMIT 300', $p);
    $tot = one("SELECT COUNT(*) n, COALESCE(SUM(signed_at IS NULL),0) unsigned_n, COALESCE(SUM(signed_at IS NOT NULL AND printed_at IS NULL),0) signed_n, COALESCE(SUM(printed_at IS NOT NULL),0) printed_n FROM delivery_notes") ?: [];
    out(['notes' => array_map(function ($d) { $o = dn_dto($d); $o['items_count'] = count($o['items']); unset($o['signature']); $o['printed'] = $d['printed_at'] !== null; $o['paid'] = ($d['rfq_status'] ?? '') === 'paid'; $o['paid_at'] = $d['rfq_paid_at'] ?? null; $o['paid_amount'] = isset($d['rfq_paid_amount']) ? (float)$d['rfq_paid_amount'] : null; return $o; }, $rows), 'counts' => array_map('intval', $tot)]);
}
if ($sub === 'delivery') {
    $did = isset($seg[2]) && ctype_digit($seg[2]) ? (int)$seg[2] : 0; $act = $seg[3] ?? ''; $d = $did ? one('SELECT d.*, u.name AS signed_by_name, c.name AS created_by_name FROM delivery_notes d LEFT JOIN users u ON u.id=d.signed_by LEFT JOIN users c ON c.id=d.created_by WHERE d.id=?', [$did]) : null; if (!$d) fail('Not found', 404);
    if ($method === 'GET' && $act === 'docx') { require_once __DIR__ . '/docxout.php'; [$bytes, $fn] = dn_docx($d); header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document'); header('Content-Disposition: attachment; filename="' . $fn . '"'); header('Content-Length: ' . strlen($bytes)); header('Cache-Control: private, no-store'); echo $bytes; exit; }
    if ($method === 'GET' && $act === '') { $co = one('SELECT company_name,address,email,phone,tax_id,website,rc_number FROM fin_settings WHERE id=1') ?: []; out(['note' => dn_dto($d), 'company' => $co]); }
    if ($method === 'PATCH' && $act === '') { if ($d['signed_at']) fail('A signed delivery note cannot be changed. It is locked.', 409); $items = $d['items']; if (isset($b['items'])) { $it = []; foreach (array_slice((array)$b['items'], 0, 100) as $i) { $dsc = fx_s($i['description'] ?? '', 500); if ($dsc) $it[] = ['description' => $dsc, 'qty' => fx_num($i['qty'] ?? 1, 1), 'unit' => fx_s($i['unit'] ?? '', 30)]; } if ($it) $items = json_encode($it, JSON_UNESCAPED_UNICODE); }
        $dd = array_key_exists('delivery_date', $b) && strtotime((string)$b['delivery_date']) ? date('Y-m-d', strtotime((string)$b['delivery_date'])) : $d['delivery_date'];
        q('UPDATE delivery_notes SET delivery_date=?, delivery_address=?, client_address=?, notes=?, items=? WHERE id=?', [$dd, array_key_exists('delivery_address', $b) ? fx_s($b['delivery_address'], 500) : $d['delivery_address'], array_key_exists('client_address', $b) ? fx_s($b['client_address'], 800) : $d['client_address'], array_key_exists('notes', $b) ? fx_s($b['notes'], 1000) : $d['notes'], $items, $did]);
        if ($d['rfq_id']) q('UPDATE rfqs SET delivery_date=? WHERE id=?', [$dd, (int)$d['rfq_id']]); out(['ok' => true]); }
    if ($method === 'POST' && $act === 'sign') { if ($d['signed_at']) fail('Already signed', 409); $sg = one('SELECT image FROM user_signatures WHERE user_id=?', [$uid]); if (!$sg) fail('Save your signature first (Finance → Approvals → My signature), then sign.', 409);
        q('UPDATE delivery_notes SET signed_by=?, signed_at=NOW(), signature=? WHERE id=?', [$uid, $sg['image'], $did]); if ($d['rfq_id']) rfq_event((int)$d['rfq_id'], 'signed', 'Delivery note ' . $d['number'] . ' signed by ' . $u['name'], $uid); out(['ok' => true]); }
    if ($method === 'POST' && $act === 'printed') { q('UPDATE delivery_notes SET printed_at=IFNULL(printed_at,NOW()), printed_by=IFNULL(printed_by,?) WHERE id=?', [$uid, $did]); if ($d['rfq_id'] && !$d['printed_at']) rfq_event((int)$d['rfq_id'], 'printed', 'Delivery note ' . $d['number'] . ' printed for signing · confirm the payment when it comes in', $uid); out(['ok' => true]); }
    fail('Not found', 404);
}
