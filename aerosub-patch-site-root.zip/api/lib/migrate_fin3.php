<?php
declare(strict_types=1);
// Finance: product / service lines, optional signatures and the discussion on a document. Runs from /upgrade.php, and by itself the first time Finance is opened.
require_once __DIR__ . '/migrate.php';

/** Finance: product / service lines, optional signatures, vendors, document looks, templates and the discussion on a document. Safe to run again. */
function migrate_fin_ext(): array {
    $log = [];
    if (!col_exists('fin_items', 'kind')) { db()->exec("ALTER TABLE fin_items ADD COLUMN kind VARCHAR(8) NULL"); $log[] = 'Finance items: product / service type added.'; }
    if (!col_exists('doc_approvals', 'require_sig')) { db()->exec('ALTER TABLE doc_approvals ADD COLUMN require_sig TINYINT(1) NOT NULL DEFAULT 1'); $log[] = 'Approvals: optional signature added.'; }
    db()->exec("CREATE TABLE IF NOT EXISTS vendors (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(190) NOT NULL, contact_name VARCHAR(160) NULL, email VARCHAR(190) NULL, phone VARCHAR(60) NULL, address VARCHAR(500) NULL, notes TEXT NULL,
        created_by INT UNSIGNED NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY (name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!col_exists('products', 'vendor_id')) { db()->exec('ALTER TABLE products ADD COLUMN vendor_id INT UNSIGNED NULL, ADD KEY (vendor_id)'); $log[] = 'Products and services: vendor added.'; }
    db()->exec("CREATE TABLE IF NOT EXISTS fin_styles (scope VARCHAR(40) NOT NULL PRIMARY KEY, data MEDIUMTEXT NOT NULL, updated_by INT UNSIGNED NULL, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE TABLE IF NOT EXISTS fin_templates (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, doc_type VARCHAR(20) NOT NULL, data MEDIUMTEXT NOT NULL, styles MEDIUMTEXT NULL, created_by INT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, KEY (doc_type)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE TABLE IF NOT EXISTS fin_comments (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, doc_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL, to_user_id INT UNSIGNED NULL, body TEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY (doc_id,id), KEY (to_user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE TABLE IF NOT EXISTS fin_letterheads (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, art_path VARCHAR(64) NULL, art_mime VARCHAR(40) NULL, pad_top DECIMAL(5,1) NOT NULL DEFAULT 52, pad_bottom DECIMAL(5,1) NOT NULL DEFAULT 44, pad_left DECIMAL(5,1) NOT NULL DEFAULT 22, pad_right DECIMAL(5,1) NOT NULL DEFAULT 22, is_default TINYINT(1) NOT NULL DEFAULT 0, created_by INT UNSIGNED NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE TABLE IF NOT EXISTS fin_letters (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(200) NOT NULL, letterhead_id INT UNSIGNED NULL, body MEDIUMTEXT NOT NULL, created_by INT UNSIGNED NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, KEY (updated_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE TABLE IF NOT EXISTS vault_shares (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, item_id INT UNSIGNED NOT NULL, owner_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL, note VARCHAR(300) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY (item_id,user_id), KEY (user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!(int)(one('SELECT COUNT(*) n FROM fin_letterheads')['n'] ?? 0)) { q("INSERT INTO fin_letterheads (name,art_path,art_mime,is_default) VALUES ('Aerosub letterhead','builtin','image/png',1)"); $log[] = 'Letters: the Aerosub letterhead was added.'; }
    db()->exec("CREATE TABLE IF NOT EXISTS news_feeds (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(160) NOT NULL, url VARCHAR(500) NOT NULL, keywords TEXT NULL, exclude_words TEXT NULL, department_id INT UNSIGNED NULL, max_items SMALLINT UNSIGNED NOT NULL DEFAULT 12, keep_days SMALLINT UNSIGNED NOT NULL DEFAULT 7, every_min SMALLINT UNSIGNED NOT NULL DEFAULT 60, active TINYINT(1) NOT NULL DEFAULT 1, last_fetch DATETIME NULL, last_error VARCHAR(250) NULL, last_added INT NOT NULL DEFAULT 0, created_by INT UNSIGNED NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    db()->exec("CREATE TABLE IF NOT EXISTS news_items (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, feed_id INT UNSIGNED NOT NULL, guid_hash CHAR(40) NOT NULL, title VARCHAR(250) NOT NULL, summary VARCHAR(500) NULL, link VARCHAR(500) NULL, published_at DATETIME NOT NULL, matched VARCHAR(200) NULL, UNIQUE KEY (feed_id,guid_hash), KEY (published_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $log[] = 'Finance: product / service types, optional signatures and document comments ready.'; return $log;
}
if (!function_exists('migrate_finance3')) { function migrate_finance3(): array { return migrate_fin_ext(); } }   // (an older migrate_finance3 may already sit in migrate.php; migrate_fin_ext has its own name so it can never be shadowed)
